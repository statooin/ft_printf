#ifndef conv_c_H
# define conv_c_H

int	conv_c_char_null(void);
int	conv_c_ascii_chars(void);
int	conv_c_ascii_chars_8_width(void);
int	conv_c_ascii_chars_8_width_flag(void);
int	conv_c_short_max(void);
/*PROTOTYPES_HERE*/

#endif
