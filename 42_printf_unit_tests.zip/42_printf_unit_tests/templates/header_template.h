#ifndef TMPL_FCT_NAME_H
# define TMPL_FCT_NAME_H

/*PROTOTYPES_HERE*/

#endif
